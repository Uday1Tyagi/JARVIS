function startJarvis(){

document.body.classList.add("active");

let recognition =
new(window.SpeechRecognition ||
window.webkitSpeechRecognition)();

recognition.start();

recognition.onstart=function(){

    let speech = new SpeechSynthesisUtterance("Jarvis Activated");

    speech.rate = 0.92;
    speech.pitch = 0.85;

    // 🔥 start glow sync
    document.body.classList.add("voice-active");

    speechSynthesis.speak(speech);

    speech.onend = function(){

        // stop glow sync
        document.body.classList.remove("voice-active");

        setTimeout(()=>{
            window.location.href="index.html";
        },400);

    };

}

}