/* =========================
   GLOBAL VARIABLES
========================= */

let recognition;
let isProcessing = false;
let wave;
let t = 0;


/* =========================
   START EVERYTHING
========================= */

window.onload = function(){

    wave = document.getElementById("wavePath");

    animateWave();

    startListening();

};


/* =========================
   MIC START
========================= */

function startListening(){

    recognition =
    new (window.SpeechRecognition ||
         window.webkitSpeechRecognition)();

    recognition.continuous = true;

    recognition.interimResults = false;

    recognition.lang = "en-IN";


    recognition.onstart = function(){

        document.getElementById("status")
        .innerText = "Listening...";

    };


    recognition.onresult = function(event){

        if(isProcessing) return;

        let query =
        event.results[event.results.length-1][0]
        .transcript.toLowerCase();

        document.getElementById("userInput")
        .value = query;


        /* glow */

        document.body.classList.add("speaking");

        setTimeout(()=>{
            document.body.classList.remove("speaking");
        },900);


        sendToBackend(query);

    };


    recognition.onerror = function(e){

        console.log("mic error:", e.error);

        restartMic();

    };


    recognition.onend = function(){

        restartMic();

    };


    recognition.start();

}


/* restart mic safely */

function restartMic(){

    if(!isProcessing){

        try{

            recognition.start();

        }

        catch(e){}

    }

}



/* =========================
   SEND TO BACKEND
========================= */
async function sendToBackend(query){

let email =
localStorage.getItem("email");


let res =
await fetch(
"http://127.0.0.1:5000/process",
{
method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({

query:query,
email:email

})

});


let data =
await res.json();


speak(data.response);

}

/* menu toggle */

function toggleMenu(){

let menu =
document.getElementById("menuDropdown");

menu.style.display =
menu.style.display==="block"
? "none"
: "block";

}


/* logout */

function logout(){

localStorage.clear();

window.location.href="login.html";

}


/* exit jarvis */

function exitJarvis(){

/* stop mic */

try{
recognition.stop();
}catch(e){}


/* shutdown voice */

speak("Shutting down. Goodbye");


/* fade effect */

document.body.style.transition="1s";

document.body.style.background="black";


setTimeout(()=>{

document.body.innerHTML=`

<div class="shutdown-screen">

<div class="shutdown-core"></div>

<h1>JARVIS</h1>

<p>System Offline</p>

</div>

`;

},800);

}
/* =========================
   SPEAK RESPONSE
========================= */

function speak(text){

    let speech =
    new SpeechSynthesisUtterance(text);

    speech.rate = 0.95;

    speech.pitch = 0.9;

    speechSynthesis.speak(speech);

}



/* =========================
   LOGOUT
========================= */

function logout(){

    localStorage.removeItem("user");

    window.location.href = "login.html";

}



/* =========================
   TYPED INPUT
========================= */

function sendTyped(){

    let input =
    document.getElementById("userInput");

    let query =
    input.value.trim().toLowerCase();

    if(!query) return;

    sendToBackend(query);

    input.value = "";

}


function handleEnter(e){

    if(e.key === "Enter"){

        sendTyped();

    }

}



/* =========================
   CIRCLE ANIMATION
========================= */

function animateWave(){

    if(!wave) return;

    let path = "";

    let cx = 150;
    let cy = 150;

    let baseRadius = 95;

    for(let i=0;i<=360;i+=2){

        let rad = i*Math.PI/180;

        let amp =
        Math.sin(rad*3+t)*4 +
        Math.cos(rad*5+t)*2;

        if(document.body.classList.contains("speaking")){

            amp =
            Math.sin(rad*4+t)*9 +
            Math.cos(rad*7+t)*5;

        }

        let r = baseRadius + amp;

        let x = cx + r*Math.cos(rad);

        let y = cy + r*Math.sin(rad);

        path += (i===0?"M":"L") + x + " " + y + " ";

    }

    path += "Z";

    wave.setAttribute("d", path);

    t += 0.05;

    requestAnimationFrame(animateWave);

}