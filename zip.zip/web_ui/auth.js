console.log("AUTH JS LOADED");


/* ========================
   UI SWITCH
======================== */

const buttons =
    document.getElementById("buttons");

const loginForm =
    document.getElementById("loginForm");

const registerForm =
    document.getElementById("registerForm");

const backBtn =
    document.getElementById("backBtn");


function showLogin() {

    buttons.style.display = "none";

    loginForm.style.display = "block";

    registerForm.style.display = "none";

    backBtn.style.display = "block";

}


function showRegister() {

    buttons.style.display = "none";

    loginForm.style.display = "none";

    registerForm.style.display = "block";

    backBtn.style.display = "block";

}


function goBack() {

    buttons.style.display = "block";

    loginForm.style.display = "none";

    registerForm.style.display = "none";

    backBtn.style.display = "none";

}



/* ========================
   LOGIN
======================== */

async function login() {

    let email =
        document.getElementById("loginEmail").value.trim();

    let pass =
        document.getElementById("loginPass").value.trim();


    if (!email || !pass) {

        alert("Fill all fields");

        return;

    }


    let res =
        await fetch(
            "http://127.0.0.1:5000/login",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({

                    email: email,

                    password: pass

                })

            });


    let data =
        await res.json();


    console.log(data);


    if (data.status == "success") {

        localStorage.setItem("email", email);

        localStorage.setItem("name", data.name);

        localStorage.setItem("dob", data.dob);


        window.location.href = "activate.html";

    }

    else {

        alert(data.message);

    }

}



/* ========================
   REGISTER
======================== */

async function register() {

    let name =
        document.getElementById("regName").value.trim();

    let email =
        document.getElementById("regEmail").value.trim();

    let dob =
        document.getElementById("regDob").value;

    let pass =
        document.getElementById("regPass").value.trim();

    let confirm =
        document.getElementById("regConfirm").value.trim();



    if (!name || !email || !dob || !pass || !confirm) {

        alert("Fill all fields");

        return;

    }


    if (pass != confirm) {

        alert("Password not match");

        return;

    }



    let res =
        await fetch(
            "http://127.0.0.1:5000/register",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({

                    name: name,

                    email: email,

                    dob: dob,

                    password: pass

                })

            });


    let data =
        await res.json();


    alert(data.message);


    /* after register go back */

    goBack();

}