import json
import os

MEMORY_FILE = os.path.join(os.path.dirname(__file__), "memory.json")


def load_memory():
    try:
        with open("memory/memory.json", "r") as f:
            data = json.load(f)

        if "user" not in data:
            data["user"] = {}

        return data

    except:
        return {"user": {}}


def save_memory(data):
    with open(MEMORY_FILE, "w") as file:
        json.dump(data, file, indent=4)


def set_memory(key, value):
    data = load_memory()
    data[key] = value
    save_memory(data)


def get_memory(key):
    data = load_memory()
    return data.get(key)